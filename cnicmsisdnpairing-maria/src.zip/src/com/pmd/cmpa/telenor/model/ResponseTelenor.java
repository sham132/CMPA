package com.pmd.cmpa.telenor.model;

public class ResponseTelenor {
	private String RequestID;
	private String Status;
	private String ResponseCode;

	public String getRequestID() {
		return RequestID;
	}
	public String getStatus() {
		return Status;
	}
	public String getResponseCode() {
		return ResponseCode;
	}
	
}
