package com.pmd.cmpa.telenor.model;

public class AuthResponse {
	private String access_token;
	private String expires_in;

	public String getAccess_token() {
		return access_token;
	}

	public String getExpires_in() {
		return expires_in;
	}

}
