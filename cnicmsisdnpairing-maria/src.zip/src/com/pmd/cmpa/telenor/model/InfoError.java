package com.pmd.cmpa.telenor.model;

public class InfoError {
	private String requestId;
	private String errorCode;
	private String errorMessage;
	public String getRequestId() {
		return requestId;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}            

}
