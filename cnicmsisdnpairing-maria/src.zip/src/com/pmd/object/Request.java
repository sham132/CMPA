package com.pmd.object;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="Request")
@XmlType(propOrder={"msisdn","cnic","transactionID"})//,"param1","param2","param3","param4"})
public class Request implements Serializable {
	private static final long serialVersionUID = -1129402159048345205L;
	private String msisdn;
	private String cnic;
	private String transactionID;
	//private String param1;
	//private String param2;
	//private String param3;
	//private String param4;
	
	public Request(){
		this.msisdn = "";
		this.cnic = "";
		this.transactionID = "";
		//this.param1 = "";
		//this.param2 = "";
		//this.param3 = "";
		//this.param4 = "";
		
	}
	public Request (String msisdn,String cnic,String transactionID,
					String param1,String param2,String param3,String param4){
		this.msisdn = msisdn;
		this.cnic = cnic;
		this.transactionID = transactionID;
		//this.param1 = param1;
		//this.param2 = param2;
		//this.param3 = param3;
		//this.param4 = param4;
	}
	@XmlElement(name="Msisdn")
	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getCnic() {
		return cnic;
	}

	public void setCnic(String cnic) {
		this.cnic = cnic;
	}

	public String getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(String transectionID) {
		this.transactionID = transectionID;
	}

//	public String getParam1() {
//		return param1;
//	}
//
//	public void setParam1(String param1) {
//		this.param1 = param1;
//	}
//
//	public String getParam2() {
//		return param2;
//	}
//
//	public void setParam2(String param2) {
//		this.param2 = param2;
//	}
//
//	public String getParam3() {
//		return param3;
//	}
//
//	public void setParam3(String param3) {
//		this.param3 = param3;
//	}
//
//	public String getParam4() {
//		return param4;
//	}
//
//	public void setParam4(String param4) {
//		this.param4 = param4;
//	}
	
}
